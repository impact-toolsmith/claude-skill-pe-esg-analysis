# -*- coding: utf-8 -*-
"""Render a long ESG analysis to a self-contained Word (.docx) file.

No external template and no logo: the script builds the whole .docx from scratch,
including the synthesis table and the coloured title blocks.

Usage:
    python3 render_esg_long.py --content analysis.md --out "ESG Analysis - <Company>.docx"

The content file (analysis.md) follows the Markdown contract described in the
installation guide (section "Long-format Word export").
"""
import re, argparse, zipfile

def esc(t): return t.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
BASE='<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>'
NAVY='1F3864'

# Colour conventions (fill, text). Semantic, brand-neutral.
EXPO = {'Strong':('305496','FFFFFF'),'Medium':('5B9BD5','000000'),'Weak':('F2F2F2','000000'),'?':('7030A0','FFFFFF')}
SOLU = {'Strong':('70AD47','FFFFFF'),'Medium':('E2EFDA','000000'),'Weak':('F2F2F2','000000'),'?':('7030A0','FFFFFF')}
MATU = {'Very advanced':('70AD47','FFFFFF'),'Advanced':('E2EFDA','000000'),'Medium':('FFF2CC','000000'),'Limited':('ED7D31','FFFFFF'),'Poor practices':('C00000','FFFFFF'),'?':('7030A0','FFFFFF')}
PILLAR = {'E':('92D050','FFFFFF'),'S':('00B0F0','FFFFFF'),'E/S':('60D9E2','FFFFFF'),'G':('FF66FF','FFFFFF')}
ARROW_COL = {'++':('70AD47','FFFFFF'),'+':('E2EFDA','000000'),'=':('FFF2CC','000000'),'-':('ED7D31','FFFFFF'),'--':('C00000','FFFFFF')}
COMBINE = {('Weak','Very advanced'):'++',('Medium','Very advanced'):'++',('Strong','Very advanced'):'+',('Weak','Advanced'):'++',('Medium','Advanced'):'+',('Strong','Advanced'):'+',('Weak','Medium'):'+',('Medium','Medium'):'=',('Strong','Medium'):'=',('Weak','Limited'):'=',('Medium','Limited'):'-',('Strong','Limited'):'-',('Weak','Poor practices'):'-',('Medium','Poor practices'):'--',('Strong','Poor practices'):'--'}
GOV_ARROW = {'Very advanced':'++','Advanced':'+','Medium':'=','Limited':'-','Poor practices':'--','?':'='}
PROD_ARROW = {'Strong':'++','Medium':'+','Weak':'=','?':'='}

def esc_run(text, rpr=''):
    return '<w:r><w:rPr>'+rpr+'</w:rPr><w:t xml:space="preserve">'+esc(text)+'</w:t></w:r>' if text else ''
def cellp(text, rpr='', jc=None, spacing=None):
    j = '<w:jc w:val="'+jc+'"/>' if jc else ''
    sp = spacing or ''
    return '<w:p><w:pPr><w:keepNext/><w:keepLines/>'+sp+j+'</w:pPr>'+esc_run(text, rpr)+'</w:p>'
def cell(w, fill, content_p, valign='center', gridspan=None):
    shd = '<w:shd w:val="clear" w:color="auto" w:fill="'+fill+'"/>' if fill else ''
    gs = '<w:gridSpan w:val="'+str(gridspan)+'"/>' if gridspan else ''
    return '<w:tc><w:tcPr><w:tcW w:w="'+str(w)+'" w:type="dxa"/>'+gs+shd+'<w:vAlign w:val="'+valign+'"/></w:tcPr>'+content_p+'</w:tc>'
NOBORD = ('<w:tblBorders><w:top w:val="none" w:sz="0" w:space="0" w:color="auto"/><w:left w:val="none" w:sz="0" w:space="0" w:color="auto"/><w:bottom w:val="none" w:sz="0" w:space="0" w:color="auto"/><w:right w:val="none" w:sz="0" w:space="0" w:color="auto"/><w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto"/><w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto"/></w:tblBorders>')
def tblpr(total, jc=None):
    j = '<w:jc w:val="'+jc+'"/>' if jc else ''
    return '<w:tblPr><w:tblW w:w="'+str(total)+'" w:type="dxa"/>'+j+NOBORD+'<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>'
HDR_RPR = BASE+'<w:b/><w:bCs/><w:sz w:val="16"/><w:szCs w:val="16"/>'
HDR_SP  = '<w:spacing w:before="0" w:after="40"/>'
EMPTY_SP= '<w:spacing w:before="0" w:after="0"/>'
ROWH    = '<w:trPr><w:cantSplit/><w:trHeight w:val="397" w:hRule="atLeast"/></w:trPr>'
HROW    = '<w:tr><w:trPr><w:cantSplit/></w:trPr>'

def body_para(text):
    return '<w:p><w:pPr><w:jc w:val="both"/><w:spacing w:after="120"/></w:pPr>'+esc_run(text, BASE)+'</w:p>'
def kicker(text):
    return '<w:p><w:pPr><w:spacing w:after="0"/></w:pPr><w:r><w:rPr>'+BASE+'<w:caps/><w:color w:val="'+NAVY+'"/><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr><w:t xml:space="preserve">'+esc(text)+'</w:t></w:r></w:p>'
def title_para(text):
    return '<w:p><w:pPr><w:spacing w:before="40" w:after="40"/></w:pPr><w:r><w:rPr>'+BASE+'<w:b/><w:bCs/><w:color w:val="0B3142"/><w:sz w:val="38"/><w:szCs w:val="38"/></w:rPr><w:t xml:space="preserve">'+esc(text)+'</w:t></w:r></w:p>'
def subtitle_para(text):
    return '<w:p><w:pPr><w:spacing w:after="240"/></w:pPr><w:r><w:rPr>'+BASE+'<w:i/><w:iCs/><w:color w:val="5A5A5A"/></w:rPr><w:t xml:space="preserve">'+esc(text)+'</w:t></w:r></w:p>'
def h1_para(text, pagebreak=False):
    pb = '<w:pageBreakBefore/>' if pagebreak else ''
    bdr = '<w:pBdr><w:bottom w:val="single" w:sz="8" w:space="2" w:color="'+NAVY+'"/></w:pBdr>'
    return '<w:p><w:pPr>'+pb+'<w:keepNext/>'+bdr+'<w:spacing w:before="260" w:after="100"/></w:pPr><w:r><w:rPr>'+BASE+'<w:b/><w:bCs/><w:color w:val="'+NAVY+'"/><w:sz w:val="27"/><w:szCs w:val="27"/></w:rPr><w:t xml:space="preserve">'+esc(text)+'</w:t></w:r></w:p>'
def h2_para(text):
    return '<w:p><w:pPr><w:keepNext/><w:spacing w:before="160" w:after="40"/></w:pPr><w:r><w:rPr>'+BASE+'<w:b/><w:bCs/><w:color w:val="2B4A7E"/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr><w:t xml:space="preserve">'+esc(text)+'</w:t></w:r></w:p>'
def impact_line(text):
    return ('<w:p><w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="360" w:after="60"/></w:pPr><w:r><w:rPr><w:i/><w:iCs/>'+BASE+'</w:rPr><w:tab/><w:t xml:space="preserve">'+esc(text)+'</w:t></w:r></w:p>')

def risk_table(letter, title, expo, matu):
    pc,pt = PILLAR.get(letter,PILLAR['S']); ec,et = EXPO.get(expo,EXPO['?']); mc,mt = MATU.get(matu,MATU['?'])
    W1,W2,W3,W4 = 620,5762,1380,1308
    grid = '<w:tblGrid><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/></w:tblGrid>'%(W1,W2,W3,W4)
    row1 = (HROW+cell(W1,'',cellp('', BASE+'<w:sz w:val="16"/><w:szCs w:val="16"/>', spacing=EMPTY_SP))
        + cell(W2,'',cellp('', BASE+'<w:sz w:val="16"/><w:szCs w:val="16"/>', spacing=EMPTY_SP))
        + cell(W3,'',cellp('Exposure', HDR_RPR,'center',spacing=HDR_SP))
        + cell(W4,'',cellp('Maturity', HDR_RPR,'center',spacing=HDR_SP))+'</w:tr>')
    row2 = ('<w:tr>'+ROWH
        + cell(W1,pc,cellp(letter, BASE+'<w:b/><w:bCs/><w:color w:val="'+pt+'"/>','center',spacing=EMPTY_SP))
        + cell(W2,'D9D9D9',cellp(title, BASE+'<w:b/><w:bCs/>','left',spacing=EMPTY_SP+'<w:ind w:left="170"/>'))
        + cell(W3,ec,cellp(expo, BASE+'<w:color w:val="'+et+'"/><w:sz w:val="16"/><w:szCs w:val="16"/>','center',spacing=EMPTY_SP))
        + cell(W4,mc,cellp(matu, BASE+'<w:color w:val="'+mt+'"/><w:sz w:val="16"/><w:szCs w:val="16"/>','center',spacing=EMPTY_SP))+'</w:tr>')
    return '<w:tbl>'+tblpr(W1+W2+W3+W4)+grid+row1+row2+'</w:tbl>'

def gov_table(title, matu):
    pc,pt = PILLAR['G']; mc,mt = MATU.get(matu,MATU['?'])
    W1,W2,W3 = 620,7142,1308
    grid = '<w:tblGrid><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/></w:tblGrid>'%(W1,W2,W3)
    row1 = (HROW+cell(W1,'',cellp('', BASE+'<w:sz w:val="16"/><w:szCs w:val="16"/>', spacing=EMPTY_SP))
        + cell(W2,'',cellp('', BASE+'<w:sz w:val="16"/><w:szCs w:val="16"/>', spacing=EMPTY_SP))
        + cell(W3,'',cellp('Maturity', HDR_RPR,'center',spacing=HDR_SP))+'</w:tr>')
    row2 = ('<w:tr>'+ROWH
        + cell(W1,pc,cellp('G', BASE+'<w:b/><w:bCs/><w:color w:val="'+pt+'"/>','center',spacing=EMPTY_SP))
        + cell(W2,'D9D9D9',cellp(title, BASE+'<w:b/><w:bCs/>','left',spacing=EMPTY_SP+'<w:ind w:left="170"/>'))
        + cell(W3,mc,cellp(matu, BASE+'<w:color w:val="'+mt+'"/><w:sz w:val="16"/><w:szCs w:val="16"/>','center',spacing=EMPTY_SP))+'</w:tr>')
    return '<w:tbl>'+tblpr(W1+W2+W3)+grid+row1+row2+'</w:tbl>'

def products_table(statement, rating, pillar, expo_type, themes):
    rc,rt = SOLU.get(rating,SOLU['?']); pc,pt = PILLAR.get(pillar,PILLAR['E'])
    PB = BASE+'<w:sz w:val="18"/><w:szCs w:val="18"/>'
    C1,C2,C3,C4,C5,C6,C7 = 3827,150,900,120,520,120,880
    grid = '<w:tblGrid>'+''.join('<w:gridCol w:w="%d"/>'%w for w in [C1,C2,C3,C4,C5,C6,C7])+'</w:tblGrid>'
    def vc(w, content='', fill='', vmerge=None, gridspan=None):
        vm = '<w:vMerge w:val="restart"/>' if vmerge=='restart' else ('<w:vMerge/>' if vmerge=='cont' else '')
        shd = '<w:shd w:val="clear" w:color="auto" w:fill="'+fill+'"/>' if fill else ''
        gs = '<w:gridSpan w:val="'+str(gridspan)+'"/>' if gridspan else ''
        return '<w:tc><w:tcPr><w:tcW w:w="'+str(w)+'" w:type="dxa"/>'+gs+vm+shd+'<w:vAlign w:val="center"/></w:tcPr>'+(content or '<w:p><w:pPr><w:keepNext/><w:keepLines/></w:pPr></w:p>')+'</w:tc>'
    P = lambda txt,rpr=PB,jc=None: cellp(txt, rpr, jc, spacing=EMPTY_SP)
    R1 = '<w:trPr><w:cantSplit/><w:trHeight w:val="150" w:hRule="atLeast"/></w:trPr>'
    RC = '<w:trPr><w:cantSplit/><w:trHeight w:val="260" w:hRule="atLeast"/></w:trPr>'
    r1 = ('<w:tr>'+R1+vc(C1, P(statement,PB,'left'), vmerge='restart')+vc(C2, P(':',PB,'center'), vmerge='restart')
        + vc(C3)+vc(C4)+vc(C5)+vc(C6)+vc(C7, P(expo_type,PB,'center'), vmerge='restart')+'</w:tr>')
    r2 = ('<w:tr>'+RC+vc(C1, vmerge='cont')+vc(C2, vmerge='cont')
        + vc(C3, P(rating, PB+'<w:color w:val="'+rt+'"/>','center'), fill=rc)+vc(C4)
        + vc(C5, P(pillar, PB+'<w:b/><w:bCs/><w:color w:val="'+pt+'"/>','center'), fill=pc)+vc(C6)
        + vc(C7, vmerge='cont')+'</w:tr>')
    r3 = ('<w:tr>'+R1+vc(C1, vmerge='cont')+vc(C2, vmerge='cont')+vc(C3)+vc(C4)+vc(C5)+vc(C6)+vc(C7, vmerge='cont')+'</w:tr>')
    rtth = ('<w:tr><w:trPr><w:cantSplit/></w:trPr>'+vc(C1, P('Theme(s)',PB,'left'))+vc(C2, P(':',PB,'center'))
        + vc(C3+C4+C5+C6+C7, P(themes,PB,'left'), gridspan=5)+'</w:tr>')
    return '<w:tbl>'+tblpr(C1+C2+C3+C4+C5+C6+C7,'center')+grid+r1+r2+r3+rtth+'</w:tbl>'

S1,S2,S3,S4,S5,S6 = 720,5471,80,620,120,360
STOT = S1+S2+S3+S4+S5+S6
SROWH = '<w:trPr><w:cantSplit/><w:trHeight w:val="312" w:hRule="atLeast"/></w:trPr>'
SEP = '<w:tr><w:trPr><w:trHeight w:val="80" w:hRule="exact"/></w:trPr>'+cell(STOT,'',cellp('', BASE+'<w:sz w:val="2"/><w:szCs w:val="2"/>', spacing=EMPTY_SP), gridspan=6)+'</w:tr>'
def synth_row(letter, title, arrow, dollar):
    pc,pt = PILLAR.get(letter,PILLAR['S']); ac,at = ARROW_COL.get(arrow,ARROW_COL['='])
    if dollar=='pos': dol = cell(S6,'70AD47',cellp('$', BASE+'<w:b/><w:bCs/><w:color w:val="FFFFFF"/>','center',spacing=EMPTY_SP))
    elif dollar=='neg': dol = cell(S6,'ED7D31',cellp('$', BASE+'<w:b/><w:bCs/><w:color w:val="FFFFFF"/>','center',spacing=EMPTY_SP))
    else: dol = cell(S6,'',cellp('',BASE,spacing=EMPTY_SP))
    return ('<w:tr>'+SROWH
        + cell(S1,pc,cellp(letter, BASE+'<w:b/><w:bCs/><w:color w:val="'+pt+'"/>','center',spacing=EMPTY_SP))
        + cell(S2,'',cellp(title, BASE,'left',spacing=EMPTY_SP))
        + cell(S3,'',cellp('',BASE,spacing=EMPTY_SP))
        + cell(S4,ac,cellp(arrow, BASE+'<w:b/><w:bCs/><w:color w:val="'+at+'"/>','center',spacing=EMPTY_SP))
        + cell(S5,'',cellp('',BASE,spacing=EMPTY_SP))+dol+'</w:tr>')
def synth_sub(text):
    return ('<w:tr><w:trPr><w:cantSplit/><w:trHeight w:val="200" w:hRule="atLeast"/></w:trPr>'
        + cell(STOT,'',cellp(text, BASE+'<w:i/><w:iCs/>','left',spacing='<w:spacing w:before="240" w:after="40"/>'), gridspan=6)+'</w:tr>')
def chip(sym, fill, txt, tail=''):
    return '<w:r><w:rPr>'+BASE+'<w:b/><w:bCs/><w:color w:val="'+txt+'"/><w:shd w:val="clear" w:color="auto" w:fill="'+fill+'"/></w:rPr><w:t xml:space="preserve">  '+esc(sym)+'  '+tail+'</w:t></w:r>'
def gap(): return '<w:r><w:rPr>'+BASE+'</w:rPr><w:t xml:space="preserve">    </w:t></w:r>'
def lbl(t): return '<w:r><w:rPr>'+BASE+'</w:rPr><w:t xml:space="preserve">'+esc(t)+'</w:t></w:r>'
def lbl2(t): return '<w:r><w:rPr>'+BASE+'<w:i/><w:iCs/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr><w:t xml:space="preserve">'+esc(t)+'</w:t></w:r>'
ANCHOR = '<w:r><w:rPr>'+BASE+'</w:rPr><w:t xml:space="preserve">'+chr(0x200b)+'</w:t></w:r>'
def synth_table(product, risks, govs):
    rows = []
    if product:
        plabel = product.get('label','Impacts of products and services')
        if product.get('main_theme'): plabel += ': ' + product['main_theme']
        rows += [synth_row(product['pillar'], plabel, product['arrow'], product['dollar'])]
    if risks:
        rows += [SEP, synth_sub('Main environmental and social risks')]
        for r in risks: rows += [SEP, synth_row(r['pillar'], r['title'], r['arrow'], r['dollar'])]
    if govs:
        rows += [SEP, synth_sub('Governance')]
        for g in govs: rows += [SEP, synth_row('G', g['title'], g['arrow'], g['dollar'])]
    grid = '<w:tblGrid>'+''.join('<w:gridCol w:w="%d"/>'%w for w in [S1,S2,S3,S4,S5,S6])+'</w:tblGrid>'
    tbl = '<w:tbl>'+tblpr(STOT,'center')+grid+''.join(rows)+'</w:tbl>'
    leg1 = ('<w:p><w:pPr><w:spacing w:before="0" w:after="80"/><w:jc w:val="center"/></w:pPr>'+lbl('ESG Maturity scale: ')
        + chip('++','70AD47','FFFFFF')+gap()+chip('+','E2EFDA','000000')+gap()+chip('=','FFF2CC','000000')+gap()
        + chip('-','ED7D31','FFFFFF')+gap()+chip('--','C00000','FFFFFF')+ANCHOR+'</w:p>')
    leg2 = ('<w:p><w:pPr><w:spacing w:before="80" w:after="120"/><w:jc w:val="center"/></w:pPr>'
        + lbl2('Potential positive financial impacts: ')+chip('$','70AD47','FFFFFF')+gap()+gap()
        + lbl2('Potential negative financial impacts: ')+chip('$','ED7D31','FFFFFF')+ANCHOR+'</w:p>')
    return '<w:p/>'+tbl+'<w:p/>'+leg1+leg2+'<w:p/>'

def md_table(raw_rows):
    rows = []
    for r in raw_rows:
        cells = [c.strip() for c in r.strip().strip('|').split('|')]
        if cells and all(re.fullmatch(r':?-{2,}:?', (c or '-')) for c in cells):
            continue
        rows.append(cells)
    if not rows: return ''
    ncols = max(len(r) for r in rows)
    total = 9360; colw = total // ncols
    grid = '<w:tblGrid>'+''.join('<w:gridCol w:w="%d"/>'%colw for _ in range(ncols))+'</w:tblGrid>'
    bord = ('<w:tblBorders>'+''.join('<w:%s w:val="single" w:sz="4" w:space="0" w:color="C8CDD6"/>'%e for e in ['top','left','bottom','right','insideH','insideV'])+'</w:tblBorders>')
    tpr = '<w:tblPr><w:tblW w:w="%d" w:type="dxa"/>%s<w:tblLook w:val="04A0"/></w:tblPr>'%(total,bord)
    out_rows = ''
    for i,r in enumerate(rows):
        cells = r + ['']*(ncols-len(r))
        hdr = (i==0)
        rpr = BASE+'<w:sz w:val="17"/><w:szCs w:val="17"/>'+('<w:b/><w:bCs/><w:color w:val="FFFFFF"/>' if hdr else '')
        fill = '1F3864' if hdr else ''
        tr = '<w:tr><w:trPr><w:cantSplit/></w:trPr>'
        for c in cells:
            tr += cell(colw, fill, cellp(c, rpr, 'left', spacing='<w:spacing w:before="10" w:after="10"/>'), valign='center')
        tr += '</w:tr>'
        out_rows += tr
    return '<w:p/><w:tbl>'+tpr+grid+out_rows+'</w:tbl><w:p/>'

def find_override(t):
    o = re.search(r'Synthesis\s*:\s*(\+\+|--|\+|=|-)', t)
    return o.group(1) if o else None
def parse_risk_notation(t):
    m = re.search(r'Exposure\s*:\s*([^|)]+?)\s*\|\s*Maturity\s*:\s*([^|)]+?)\s*[|)]', t)
    expo = m.group(1).strip() if m else '?'; matu = m.group(2).strip() if m else '?'
    clean = re.sub(r'\s*\(Exposure.*?\)\s*$','',t).strip()
    return clean, expo, matu, find_override(t)
def parse_matu(t):
    m = re.search(r'Maturity\s*:\s*([^|)]+?)\s*[|)]', t)
    matu = m.group(1).strip() if m else '?'
    clean = re.sub(r'\s*\(Maturity.*?\)\s*$','',t).strip()
    return clean, matu, find_override(t)
PILL_RE = re.compile(r'^\[(E/S|E|S|G)\]\s*')
def sign_to_dollar(t):
    m = re.search(r',\s*([+\-=])\s*\)', t)
    if not m: return None
    return {'+':'pos','-':'neg','=':None}.get(m.group(1))

def parse(content):
    lines = content.split('\n')
    title = subtitle = None
    elements = []
    product = None; risks = []; govs = []; current = None
    buf = []
    in_table = False; tbl_rows = []
    def flush():
        nonlocal buf
        txt = ' '.join(x.strip() for x in buf if x.strip())
        if txt: elements.append(('para', txt))
        buf = []
    for ln in lines:
        s = ln.strip()
        if s.startswith('|'):
            flush(); tbl_rows.append(s); in_table = True; continue
        if in_table:
            elements.append(('table', tbl_rows)); tbl_rows = []; in_table = False
        mt = re.match(r'^TITLE\s*:\s*(.+)$', s)
        ms = re.match(r'^SUBTITLE\s*:\s*(.+)$', s)
        me = re.match(r'^\[HEADER\]\s*(.+)$', s, re.I)
        if mt: title = mt.group(1).strip(); continue
        if ms: subtitle = ms.group(1).strip(); continue
        if me:
            flush()
            kv = {}
            for part in me.group(1).split('|'):
                if '=' in part:
                    k,v = part.split('=',1); kv[k.strip().lower()] = v.strip()
            note = kv.get('note','?'); pil = kv.get('pillar','E'); ex = kv.get('exposure','')
            th = kv.get('themes','')
            ovr = kv.get('synthesis')
            scope = (kv.get('scope','both') or 'both').strip().lower()
            scope_label = {'products':'Impacts of products','services':'Impacts of services'}.get(scope,'Impacts of products and services')
            scope_word = {'products':'products','services':'services'}.get(scope,'products and services')
            main_theme = th.split(',')[0].strip() if th else ''
            product = {'pillar':pil,'arrow':ovr or PROD_ARROW.get(note,'='),'dollar':None,
                       'statement':kv.get('statement','Exposure to '+scope_word+' with a positive impact on environmental and social themes'),
                       'note':note,'expo_type':ex,'themes':th,'label':scope_label,'main_theme':main_theme}
            current = product
            elements.append(('products', product)); continue
        if s.startswith('### ') or re.match(r'^#{2,3}\s+Potential financial impacts', s, re.I):
            inner = re.sub(r'^#{1,6}\s+','',s)
            if inner.lower().startswith('potential financial impacts'):
                flush()
                d = sign_to_dollar(inner)
                if current is not None and current.get('dollar') is None and d: current['dollar'] = d
                elements.append(('impact', inner)); continue
        if s.startswith('## '):
            flush()
            inner = s[3:].strip()
            mp = PILL_RE.match(inner)
            if mp and mp.group(1) == 'G':
                rest = PILL_RE.sub('', inner)
                if re.search(r'Exposure\s*:', rest):
                    ttl, expo, matu, ovr = parse_risk_notation(rest)
                    e = {'title':ttl,'arrow':ovr or COMBINE.get((expo,matu),'='),'dollar':None,'matu':matu,'expo':expo}
                else:
                    ttl, matu, ovr = parse_matu(rest)
                    e = {'title':ttl,'arrow':ovr or GOV_ARROW.get(matu,'='),'dollar':None,'matu':matu}
                govs.append(e); current = e
                elements.append(('gov', e)); continue
            if mp:
                pil = mp.group(1); rest = PILL_RE.sub('', inner)
                ttl, expo, matu, ovr = parse_risk_notation(rest)
                e = {'pillar':pil,'title':ttl,'arrow':ovr or COMBINE.get((expo,matu),'='),'dollar':None,'expo':expo,'matu':matu}
                risks.append(e); current = e
                elements.append(('risk', e)); continue
            elements.append(('h2', inner)); continue
        if s.startswith('# '):
            flush()
            inner = s[2:].strip()
            inner = re.sub(r'\s*\(Governance quality.*?\)\s*$','',inner).strip()
            elements.append(('h1', inner)); continue
        if s == '':
            flush(); continue
        buf.append(ln)
    if in_table: elements.append(('table', tbl_rows))
    flush()
    return title, subtitle, elements, product, risks, govs

def render_body(content):
    title, subtitle, elements, product, risks, govs = parse(content)
    if not title: raise SystemExit("ERROR: missing 'TITLE: <Company>' line in the content.")
    out = []
    out.append(kicker('ESG Analysis'))
    out.append(title_para(title))
    if subtitle: out.append(subtitle_para(subtitle))
    after_block = False
    for el in elements:
        k = el[0]
        if k == 'h1':
            t = el[1]
            pb = t.lower().startswith('complementary synthesis')
            out.append(h1_para(t, pagebreak=pb))
            if t.lower() == 'synthesis':
                out.append(synth_table(product, risks, govs))
            after_block = False
        elif k == 'h2':
            out.append(h2_para(el[1])); after_block = False
        elif k == 'products':
            p = el[1]; out.append(products_table(p['statement'], p['note'], p['pillar'], p['expo_type'], p['themes']))
            out.append('<w:p/>'); after_block = False
        elif k == 'risk':
            e = el[1]; out.append(risk_table(e['pillar'], e['title'], e['expo'], e['matu'])); after_block = True
        elif k == 'gov':
            e = el[1]
            if e.get('expo'):
                out.append(risk_table('G', e['title'], e['expo'], e['matu']))
            else:
                out.append(gov_table(e['title'], e['matu']))
            after_block = True
        elif k == 'impact':
            out.append(impact_line(el[1])); after_block = False
        elif k == 'table':
            out.append(md_table(el[1])); after_block = False
        elif k == 'para':
            out.append(body_para(el[1]) if not after_block else body_para_sb(el[1])); after_block = False
    return '\n'.join(out)

def body_para_sb(text):
    return '<w:p><w:pPr><w:jc w:val="both"/><w:spacing w:before="120" w:after="120"/></w:pPr>'+esc_run(text, BASE)+'</w:p>'

WNS = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
       'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"')
SECTPR = '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>'
CONTENT_TYPES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
 '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
 '<Default Extension="xml" ContentType="application/xml"/>'
 '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
 '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
 '</Types>')
RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
 '</Relationships>')
DOC_RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
 '</Relationships>')
STYLES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
 '<w:styles '+WNS+'><w:docDefaults><w:rPrDefault><w:rPr>'+BASE+'<w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr></w:rPrDefault></w:docDefaults>'
 '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>')

def build_docx(out_path, body_xml):
    document = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document '+WNS+'><w:body>'+body_xml+SECTPR+'</w:body></w:document>')
    with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', CONTENT_TYPES)
        z.writestr('_rels/.rels', RELS)
        z.writestr('word/_rels/document.xml.rels', DOC_RELS)
        z.writestr('word/styles.xml', STYLES)
        z.writestr('word/document.xml', document)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--content', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    content = open(a.content, encoding='utf-8').read()
    body_xml = render_body(content)
    build_docx(a.out, body_xml)
    print('OK ->', a.out)

if __name__ == '__main__':
    main()
