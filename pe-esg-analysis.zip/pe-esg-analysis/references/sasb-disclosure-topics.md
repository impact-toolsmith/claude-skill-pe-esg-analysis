# SASB Standards : sector materiality checklist

Source: SASB Standards Navigator (Materiality Finder), IFRS Foundation - public data. 77 industries across 11 macro-sectors.

Usage: find the target's sector (search by industry name), read ONLY that block, and use it as a safety net to make sure no material issue is missed. A one-line description is given only for the less self-explanatory topics. Topic labels are in English (official SASB terminology); transpose them into your analysis language.

## Consumer Goods

### 1. Apparel, Accessories & Footwear
- Management of Chemicals in Products
- Environmental Impacts in the Supply Chain
- Labour Conditions in the Supply Chain
- Raw Materials Sourcing

### 2. Appliance Manufacturing
- Product Safety
- Product Lifecycle Environmental Impacts : Entities in the Appliance Manufacturing industry seek to differentiate their products from those of competitors.

### 3. Building Products & Furnishings
- Energy Management in Manufacturing
- Management of Chemicals in Products
- Product Lifecycle Environmental Impacts : Depending on the specific building product or furnishing, significant environmental impacts can arise during raw material sourcing, transportation, manufacturing, use-phase or end-of-life.
- Wood Supply Chain Management

### 4. E-Commerce
- Hardware Infrastructure Energy & Water Management
- Data Privacy & Advertising Standards
- Data Security
- Employee Recruitment, Inclusion & Performance
- Product Packaging & Distribution : A significant part of the E-Commerce industry’s added value comes from an entity’s ability to move a wide array of goods efficiently to consumers who would otherwise have to personally travel to collect the...

### 5. Household & Personal Products
- Water Management
- Product Environmental, Health and Safety Performance
- Packaging Lifecycle Management : The Household & Personal Products industry uses a large quantity of materials for product packaging, which often constitutes a significant portion of entities’ expenses.
- Environmental & Social Impacts of Palm Oil Supply Chain

### 6. Multiline and Specialty Retailers & Distributors
- Energy Management in Retail & Distribution
- Data Security
- Labour Practices
- Workforce Diversity & Inclusion
- Product Sourcing, Packaging & Marketing : Entities in the Multiline and Specialty Retailers & Distributors industry sell a wide array of products including electronics, clothing, furnishings and cosmetics, all of which have environmental and social...

### 7. Toys & Sporting Goods
- Chemical & Safety Hazards of Products
- Labour Conditions in the Supply Chain

## Extractives & Minerals Processing

### 8. Coal Operations
- Greenhouse Gas Emissions
- Water Management
- Waste Management
- Biodiversity Impacts
- Rights of Indigenous Peoples
- Community Relations
- Labour Relations
- Workforce Health & Safety
- Reserves Valuation & Capital Expenditures : Coal entities may be unable to extract a significant proportion of their coal reserves if greenhouse gas (GHG) emissions are controlled to limit global temperature increases.
- Tailings Storage Facilities Management : Coal waste impoundments or fine coal refuse ponds, also called tailings storage facilities (TSFs), can leak and contaminate water supplies if mismanaged, potentially leading to adverse impacts on the...

### 9. Construction Materials
- Greenhouse Gas Emissions
- Air Quality
- Energy Management
- Water Management
- Waste Management
- Biodiversity Impacts
- Workforce Health & Safety
- Product Innovation : Innovations in building materials are an essential component in the growth of sustainable construction.
- Pricing Integrity & Transparency

### 10. Iron & Steel Producers
- Greenhouse Gas Emissions
- Air Quality
- Energy Management
- Water Management
- Waste Management
- Workforce Health & Safety
- Supply Chain Management

### 11. Metals & Mining
- Greenhouse Gas Emissions
- Air Quality
- Energy Management
- Water Management
- Waste & Hazardous Materials Management
- Biodiversity Impacts
- Security, Human Rights & Rights of Indigenous Peoples
- Community Relations
- Labour Practices
- Workforce Health & Safety
- Business Ethics & Transparency
- Tailings Storage Facilities Management : The Metals & Mining industry faces significant operational hazards, particularly those associated with the structural integrity of tailings storage facilities (TSFs).

### 12. Oil & Gas – Exploration & Production
- Greenhouse Gas Emissions
- Air Quality
- Water Management
- Biodiversity Impacts
- Security, Human Rights & Rights of Indigenous Peoples
- Community Relations
- Workforce Health & Safety
- Reserves Valuation & Capital Expenditures : Exploration and production (E&P) entities may be unable to extract a significant proportion of their proved and probable oil and gas reserves if greenhouse gas (GHG) emissions are controlled to limit global...
- Business Ethics & Transparency
- Management of the Legal & Regulatory Environment : The Exploration & Production (E&P) industry is subject to numerous sustainability-related regulations and a rapidly changing regulatory environment.
- Critical Incident Risk Management : The Exploration & Production (E&P) industry faces significant hazards associated with exploration, development and production activities.

### 13. Oil & Gas – Midstream
- Greenhouse Gas Emissions
- Air Quality
- Ecological Impacts
- Competitive Behaviour
- Operational Safety, Emergency Preparedness & Response : Entities in the Oil & Gas – Midstream industry operate a vast network of assets at risk of spills and accidents.

### 14. Oil & Gas – Refining & Marketing
- Greenhouse Gas Emissions
- Air Quality
- Water Management
- Hazardous Materials Management
- Workforce Health & Safety
- Product Specifications & Clean Fuel Blends : Some regulatory jurisdictions have implemented product specifications and renewable fuel blends, which pose significant compliance and operational risks for Refining & Marketing (R&M) entities.
- Pricing Integrity & Transparency
- Management of the Legal & Regulatory Environment : The Refining & Marketing (R&M) industry is subject to numerous sustainability-related regulations and an often rapidly changing regulatory environment.
- Critical Incident Risk Management : The operations of Refining & Marketing (R&M) entities are often characterised by a high number of hazards, including the handling of flammable, volatile substances, the use of highly reactive chemicals, and...

### 15. Oil & Gas – Services
- Emissions Reduction Services & Fuels Management
- Water Management Services
- Chemicals Management
- Ecological Impact Management
- Workforce Health & Safety
- Business Ethics & Payments Transparency
- Management of the Legal & Regulatory Environment : The Oil & Gas – Services industry is subject to numerous sustainability-related regulations and a rapidly changing regulatory environment.
- Critical Incident Risk Management : Entities in the Oil & Gas – Services industry are subject to significant risks associated with low-probability, high-consequence events associated with oil and gas exploration, development and production...

## Financials

### 16. Asset Management & Custody Activities
- Transparent Information & Fair Advice for Customers : Asset managers have legal obligations and fiduciary duties related to record keeping, operating and marketing, disclosure requirements and prevention of fraudulent activities.
- Employee Diversity & Inclusion
- Incorporation of Environmental, Social, and Governance Factors in Investment Management & Advisory : Asset Management & Custody Activities entities maintain a fiduciary responsibility to their clients.
- Financed Emissions : Entities participating in asset management activities face risks and opportunities related to the greenhouse gas emissions associated with those activities.
- Business Ethics

### 17. Commercial Banks
- Data Security
- Financial Inclusion & Capacity Building
- Incorporation of Environmental, Social, and Governance Factors in Credit Analysis : As financial intermediaries, commercial banks contribute to significant positive and negative environmental and social externalities through their lending practices.
- Financed Emissions : Entities participating in commercial banking activities face risks and opportunities related to the greenhouse gas emissions associated with those activities.
- Business Ethics
- Systemic Risk Management : Commercial Bank entities that fail to manage risks to capital effectively may suffer significant losses while increasing their liabilities.

### 18. Consumer Finance
- Customer Privacy
- Data Security
- Selling Practices : Selling practices encompasses performance in three important areas that can affect an entity’s operations and financial condition.

### 19. Insurance
- Transparent Information & Fair Advice for Customers : Insurance products play an important societal role in alleviating unexpected economic shocks, allowing individual policyholders to reduce the financial consequences of events such as illnesses, accidents and...
- Incorporation of Environmental, Social and Governance Factors in Investment Management : Insurance entities must invest capital to preserve accumulated premium revenues equivalent to expected policy claim pay-outs and maintain long-term asset-liability parity.
- Policies Designed to Incentivise Responsible Behaviour : Advances in technology and the development of new policy products have allowed insurance entities to limit claim payments while encouraging responsible behaviour.
- Financed Emissions : Entities participating in insurance activities face risks and opportunities related to the greenhouse gas emissions associated with those activities.
- Physical Risk Exposure
- Systemic Risk Management : Entities in the Insurance industry have the potential to pose, amplify or transmit a threat to the financial system.

### 20. Investment Banking & Brokerage
- Employee Diversity & Inclusion
- Incorporation of Environmental, Social, and Governance Factors in Investment Banking & Brokerage Activities : Environmental, social and governance (ESG) factors may have material impacts on the entities assets and projects across a range of industries to which investment banks provide services or in which they invest.
- Business Ethics
- Professional Integrity
- Systemic Risk Management : Investment Banking & Brokerage entities that fail to manage risks to capital effectively may suffer significant value losses to their financial assets while increasing liabilities.
- Employee Incentives & Risk-taking : Variations in employee compensation structures in the Investment Banking & Brokerage industry may incentivise employees to focus on short- or long-term entity performance.

### 21. Mortgage Finance
- Lending Practices : The approach mortgage finance entities take when incentivising employees and how they communicate with customers is important for more than one reason.
- Discriminatory Lending : The Mortgage Finance industry aggregates data to determine loan terms and conditions including important provisions such as loan size, interest rate, up-front points or other fees.
- Environmental Risk to Mortgaged Properties

### 22. Security & Commodity Exchanges
- Promoting Transparent & Efficient Capital Markets : Security and commodity exchanges have a responsibility to ensure equal access to capital markets for all investors.
- Managing Conflicts of Interest
- Managing Business Continuity & Technology Risks : Security and commodity exchanges face increased risks and opportunities associated with information technology.

## Food & Beverage

### 23. Agricultural Products
- Greenhouse Gas Emissions
- Energy Management
- Water Management
- Food Safety
- Workforce Health & Safety
- Environmental & Social Impacts of Ingredient Supply Chain
- GMO Management
- Ingredient Sourcing

### 24. Alcoholic Beverages
- Energy Management
- Water Management
- Responsible Drinking & Marketing : The irresponsible consumption of alcoholic beverages can lead to negative social externalities such as drunk driving, addiction, underage drinking, death and many other public health issues.
- Packaging Lifecycle Management : Packaging materials represent a significant cost to entities in the Alcoholic Beverages industry.
- Environmental & Social Impacts of Ingredient Supply Chain
- Ingredient Sourcing

### 25. Food Retailers & Distributors
- Fleet Fuel Management
- Air Emissions from Refrigeration
- Energy Management
- Food Waste Management
- Data Security
- Food Safety
- Product Health & Nutrition : Consumer awareness of food content and nutritional value and their relationship to health, shapes the industry’s competitive landscape.
- Product Labelling & Marketing : Communication with consumers through product labelling and marketing is an important facet of food retail.
- Labour Practices
- Management of Environmental & Social Impacts in the Supply Chain

### 26. Meat, Poultry & Dairy
- Greenhouse Gas Emissions
- Energy Management
- Water Management
- Land Use & Ecological Impacts
- Food Safety
- Antibiotic Use in Animal Production : In livestock production, prevalent use of antibiotics that are also administered to humans may promote the development of antibiotic-resistant strains of bacteria.
- Workforce Health & Safety
- Animal Care & Welfare : Entities in the Meat, Poultry & Dairy industry are especially sensitive to changes in the public perception of animal welfare.
- Environmental & Social Impacts of Animal Supply Chain
- Animal & Feed Sourcing

### 27. Non-Alcoholic Beverages
- Fleet Fuel Management
- Energy Management
- Water Management
- Health & Nutrition : Nutritional and health concerns such as obesity, ingredient safety, nutritional content and adverse health impacts resulting from the consumption of non-alcoholic beverages are important factors in how...
- Product Labelling & Marketing : Communication with consumers through product labelling and marketing is an important facet of the Non-Alcoholic Beverages industry.
- Packaging Lifecycle Management : Packaging materials represent a significant cost to entities in the Non-Alcoholic Beverages industry.
- Environmental & Social Impacts of Ingredient Supply Chain
- Ingredient Sourcing

### 28. Processed Foods
- Energy Management
- Water Management
- Food Safety
- Health & Nutrition : Nutritional and health concerns such as obesity, ingredient safety and nutritional value are important factors in how entities compete with one another.
- Product Labelling & Marketing : Communication with consumers through product labelling and marketing is an important facet of the Processed Foods industry.
- Packaging Lifecycle Management : Packaging materials represent a major business cost and contribute to the environmental footprint of entities in the Processed Foods industry.
- Environmental & Social Impacts of Ingredient Supply Chain
- Ingredient Sourcing

### 29. Restaurants
- Energy Management
- Water Management
- Food & Packaging Waste Management
- Food Safety
- Nutritional Content : Public health concerns around obesity have focused on the Restaurants industry.
- Labour Practices
- Supply Chain Management & Food Sourcing

### 30. Tobacco
- Public Health : Tobacco use can create serious health risks as established by many scientific studies over the past several decades.
- Marketing Practices : Tobacco product labelling and marketing is regulated heavily internationally.

## Health Care

### 31. Biotechnology & Pharmaceuticals
- Safety of Clinical Trial Participants
- Access to Medicines
- Affordability & Pricing
- Drug Safety
- Counterfeit Drugs : Fake or substandard medication presents a significant risk to consumers in all countries.
- Ethical Marketing : Biotechnology & Pharmaceuticals entities face challenges associated with the marketing of specific products.
- Employee Recruitment, Development & Retention
- Supply Chain Management
- Business Ethics

### 32. Drug Retailers
- Energy Management in Retail
- Data Security & Privacy
- Drug Supply Chain Integrity
- Management of Controlled Substances : Drug Retailers are distributors and sellers of a wide variety of controlled substances.
- Patient Health Outcomes : Drug Retailers and pharmacists play an important role in the health care system, since they provide patients with medications and are often the last health care professionals to interact with patients before...

### 33. Health Care Delivery
- Energy Management
- Waste Management
- Patient Privacy & Electronic Health Records
- Access for Low-Income Patients
- Quality of Care & Patient Satisfaction
- Management of Controlled Substances : The Health Care Delivery industry is in a unique position with respect to the evolving use of controlled substances and managing the risk of addiction.
- Pricing & Billing Transparency : Concern regarding pricing and billing transparency in the Health Care Delivery industry has resulted in increased legal and regulatory scrutiny in some jurisdictions.
- Workforce Health & Safety
- Employee Recruitment, Development & Retention
- Climate Change Impacts on Human Health & Infrastructure
- Fraud & Unnecessary Procedures

### 34. Health Care Distributors
- Fleet Fuel Management
- Product Safety
- Counterfeit Drugs : The World Health Organization (WHO) estimates that counterfeit drugs represent more than 10% of the pharmaceutical supply chain in low- and middle-income countries.
- Product Lifecycle Management : Health Care Distributors have a responsibility to reduce the environmental impact of the products that they distribute.
- Business Ethics

### 35. Managed Care
- Customer Privacy & Technology Standards
- Access to Coverage
- Plan Performance
- Improved Outcomes : Entities in the Managed Care industry can play a critical role in maintaining and improving the health of enrolees.
- Climate Change Impacts on Human Health

### 36. Medical Equipment & Supplies
- Affordability & Pricing
- Product Safety
- Ethical Marketing : Entities in the Medical Equipment & Supplies industry face legal and regulatory challenges associated with product marketing.
- Product Design & Lifecycle Management : Medical equipment and supplies entities face increasing challenges associated with the human and environmental impact of the industry’s products.
- Supply Chain Management
- Business Ethics

## Infrastructure

### 37. Electric Utilities & Power Generators
- Greenhouse Gas Emissions & Energy Resource Planning
- Air Quality
- Water Management
- Coal Ash Management
- Energy Affordability
- Workforce Health & Safety
- End-Use Efficiency & Demand : Energy efficiency is a low-lifecycle-cost method to reduce greenhouse gas (GHG) emissions, because less electricity needs to be generated to provide the same end-use energy services.
- Nuclear Safety & Emergency Management : Although rare, nuclear accidents can have significant human health and environmental consequences because of their severity.
- Grid Resiliency : Electricity is critical for the continued function of most elements of modern life, from medicine to finance, creating a societal reliance on continuous service.

### 38. Engineering & Construction Services
- Environmental Impacts of Project Development
- Structural Integrity & Safety
- Workforce Health & Safety
- Lifecycle Impacts of Buildings & Infrastructure : Buildings and major infrastructure projects are among the largest users of natural resources in the economy; during construction, these materials include iron and steel products, cement, concrete, bricks...
- Climate Impacts of Business Mix : Engineering & Construction Services industry clients may be exposed to potentially disruptive climate regulation as well as those that mitigate climate change.
- Business Ethics

### 39. Gas Utilities & Distributors
- Energy Affordability
- End-Use Efficiency : Natural gas produces fewer greenhouse gas (GHG) emissions than other fossil fuels.
- Integrity of Gas Delivery Infrastructure : Operating a vast network of gas pipelines, equipment and storage facilities requires a multifaceted, long-term approach to ensuring infrastructure integrity and managing related risks.

### 40. Home Builders
- Land Use & Ecological Impacts
- Workforce Health & Safety
- Design for Resource Efficiency : Residential buildings, when occupied, consume significant amounts of energy and water.
- Community Impacts of New Developments : Community and urban planning provide home builders with the opportunity to thoughtfully design new residential developments in ways that benefits customers as well as the surrounding community.
- Climate Change Adaptation : The impacts of climate change, including extreme weather events and changing climate patterns, may affect the markets entities select to develop homes and residential communities.

### 41. Real Estate
- Energy Management
- Water Management
- Management of Tenant Sustainability Impacts : Real estate assets generate significant sustainability impacts, including resource consumption (energy and water), waste generation and impacts on occupant health through indoor environmental quality.
- Climate Change Adaptation

### 42. Real Estate Services
- Sustainability Services : In the Real Estate Services industry, buildings owned or occupied by clients generally have significant sustainability impacts.
- Transparent Information & Management of Conflict of Interest

### 43. Waste Management
- Greenhouse Gas Emissions
- Fleet Fuel Management
- Air Quality
- Management of Leachate & Hazardous Waste
- Labour Practices
- Workforce Health & Safety
- Recycling & Resource Recovery : Recycling, reuse, composting and incineration are general methods of diverting waste from landfills.

### 44. Water Utilities & Services
- Energy Management
- Distribution Network Efficiency
- Effluent Quality Management
- Water Affordability & Access
- Drinking Water Quality
- End-Use Efficiency : Consumer level water efficiency and conservation—whether a product of government mandates, environmental consciousness or demographic trends—is increasingly important for long-term resource availability and...
- Water Supply Resilience
- Network Resiliency & Impacts of Climate Change

## Renewable Resources & Alternative Energy

### 45. Biofuels
- Air Quality
- Water Management in Manufacturing
- Lifecycle Emissions Balance : The rapid growth in global biofuels production has been encouraged by government energy policies that seek to reduce net GHG emissions from transportation fuels and dependence on fossil fuels.
- Sourcing & Environmental Impacts of Feedstock Production
- Management of the Legal & Regulatory Environment : The Biofuels industry is dependent on government policies and regulations that create market demand and incentivise supply with tax breaks and other support for feedstock production.
- Operational Safety, Emergency Preparedness & Response : Biofuel production presents operational safety hazards because of the presence of flammable and explosive substances, high temperatures, and pressurised equipment.

### 46. Forestry Management
- Ecosystem Services & Impacts
- Rights of Indigenous Peoples
- Climate Change Adaptation

### 47. Fuel Cells & Industrial Batteries
- Energy Management
- Workforce Health & Safety
- Product Efficiency : Both customer demand and regulatory requirements are driving innovation in energy-efficient products with lower environmental impacts and lower total cost of ownership.
- Product End-of-life Management : As the rate of adoption of fuel cells and industrial batteries increases and more products reach their end of life, designing products to facilitate end-of-life management and maximise materials efficiency may...
- Materials Sourcing

### 48. Pulp & Paper Products
- Greenhouse Gas Emissions
- Air Quality
- Energy Management
- Water Management
- Supply Chain Management

### 49. Solar Technology & Project Developers
- Energy Management in Manufacturing
- Water Management in Manufacturing
- Hazardous Waste Management
- Ecological Impacts of Project Development
- Management of Energy Infrastructure Integration & Related Regulations : Entities in the industry have faced challenges in establishing solar energy as a cost-competitive means of energy production and GHG reduction, and they have encountered difficulty in capturing a greater...
- Product End-of-life Management : Solar panels may contain hazardous substances as well as reusable materials of high economic value.
- Materials Sourcing

### 50. Wind Technology & Project Developers
- Workforce Health & Safety
- Ecological Impacts of Project Development : Wind farm development involves siting, land acquisition, permitting and engagement with local stakeholders to manage environmental and community impacts.
- Materials Sourcing
- Materials Efficiency

## Resource Transformation

### 51. Aerospace & Defence
- Energy Management
- Hazardous Waste Management
- Data Security
- Product Safety
- Fuel Economy & Emissions in Use-phase : Customer preferences and regulatory incentives are increasing the demand for energy-efficient and reduced-emissions products in the Aerospace & Defence industry.
- Materials Sourcing
- Business Ethics

### 52. Chemicals
- Greenhouse Gas Emissions
- Air Quality
- Energy Management
- Water Management
- Hazardous Waste Management
- Community Relations
- Workforce Health & Safety
- Product Design for Use-phase Efficiency : As increasing resource scarcity and regulations encourage greater materials efficiency and lower energy consumption and emissions, the Chemicals industry may benefit from developing products that enhance...
- Safety & Environmental Stewardship of Chemicals : Product safety and stewardship is a critical issue for entities in the Chemicals industry.
- Genetically Modified Organisms : Some chemical entities produce crop seeds developed using genetically modified organism (GMO) technology.
- Management of the Legal & Regulatory Environment : The Chemicals industry faces strict regulation governing air emissions, water discharge, chemical safety and process safety, among other issues.
- Operational Safety, Emergency Preparedness & Response : Health, safety and emergency management is a critical issue for entities in the Chemicals industry.

### 53. Containers & Packaging
- Greenhouse Gas Emissions
- Air Quality
- Energy Management
- Water Management
- Waste Management
- Product Safety
- Product Lifecycle Management : Containers and packaging entities face opportunities and challenges associated with the potential environmental impacts of their products throughout their lifecycle.
- Supply Chain Management

### 54. Electrical & Electronic Equipment
- Energy Management
- Hazardous Waste Management
- Product Safety
- Product Lifecycle Management : Electrical and electronic equipment entities face increasing challenges and opportunities associated with environmental and social externalities that may stem from the use of their products.
- Materials Sourcing
- Business Ethics

### 55. Industrial Machinery & Goods
- Energy Management
- Workforce Health & Safety
- Fuel Economy & Emissions in Use-phase : Many of the Industrial Machinery & Goods industry’s products are powered by fossil fuels and release greenhouse gases (GHGs) and other air emissions during use.
- Materials Sourcing
- Remanufacturing Design & Services

## Services

### 56. Advertising & Marketing
- Data Privacy
- Advertising Integrity : Entities have a legal responsibility to ensure their products and services advertising is truthful and not deceptive.
- Workforce Diversity & Inclusion

### 57. Casinos & Gaming
- Energy Management
- Responsible Gaming : Although the main purpose of gambling is entertainment, the industry faces a negative perception often related to pathological gambling.
- Smoke-free Casinos
- Internal Controls on Money Laundering

### 58. Education
- Data Security
- Quality of Education & Gainful Employment : Increasing tuition payments require more students to finance their education with government and private loans.
- Marketing & Recruiting Practices : For-profit education entities that grow the number of students that they admit and enrol will increase revenue.

### 59. Hotels & Lodging
- Energy Management
- Water Management
- Ecological Impacts
- Labour Practices
- Climate Change Adaptation

### 60. Leisure Facilities
- Energy Management
- Customer Safety
- Workforce Health & Safety

### 61. Media & Entertainment
- Media Pluralism : Media pluralism, which is diversity in the broadest sense, includes both external and internal pluralism.
- Journalistic Integrity & Sponsorship Identification : Audiences rely on journalists for accurate and timely information on current events.
- Intellectual Property Protection & Media Piracy

### 62. Professional & Commercial Services
- Data Security
- Workforce Diversity & Engagement
- Professional Integrity

## Technology & Communications

### 63. Electronic Manufacturing Services & Original Design Manufacturing
- Water Management
- Waste Management
- Labour Practices
- Workforce Conditions, Health & Safety
- Product Lifecycle Management : Entities in the Electronic Manufacturing Services (EMS) & Original Design Manufacturing (ODM) industry, along with the industry’s customers such as hardware entities, face increasing challenges associated with...
- Materials Sourcing

### 64. Hardware
- Product Security
- Employee Diversity & Inclusion
- Product Lifecycle Management : Entities in the Hardware industry face increasing challenges associated with environmental and social externalities attributed to product manufacturing, transport, use and disposal.
- Supply Chain Management
- Materials Sourcing

### 65. Internet Media & Services
- Environmental Footprint of Hardware Infrastructure
- Data Privacy, Advertising Standards & Freedom of Expression
- Data Security
- Employee Recruitment, Inclusion & Performance
- Intellectual Property Protection & Competitive Behaviour

### 66. Semiconductors
- Greenhouse Gas Emissions
- Energy Management in Manufacturing
- Water Management
- Waste Management
- Workforce Health & Safety
- Recruiting & Managing a Global & Skilled Workforce
- Product Lifecycle Management : As an increasing number of devices become connected to each other and to the internet, semiconductor entities face greater demand for products that increase computing power and decrease energy costs.
- Materials Sourcing
- Intellectual Property Protection & Competitive Behaviour

### 67. Software & IT Services
- Environmental Footprint of Hardware Infrastructure
- Data Privacy & Freedom of Expression
- Data Security
- Recruiting & Managing a Global, Diverse & Skilled Workforce
- Intellectual Property Protection & Competitive Behaviour
- Managing Systemic Risks from Technology Disruptions : With trends towards increased cloud computing and Software as a Service (SaaS), software and IT service providers must ensure they have robust infrastructure and policies in place to minimise disruptions to...

### 68. Telecommunication Services
- Environmental Footprint of Operations
- Data Privacy
- Data Security
- Product End-of-life Management
- Competitive Behaviour & Open Internet
- Managing Systemic Risks from Technology Disruptions : Given the systemic importance of telecommunications networks, systemic or economy-wide disruption may result if the Telecommunication Services network infrastructure is unreliable and prone to business...

## Transportation

### 69. Air Freight & Logistics
- Greenhouse Gas Emissions
- Air Quality
- Labour Practices
- Workforce Health & Safety
- Supply Chain Management
- Accident & Safety Management : All modes of transportation pose safety risks.

### 70. Airlines
- Greenhouse Gas Emissions
- Labour Practices
- Competitive Behaviour
- Accident & Safety Management : Air travel accidents may result in significant consequences.

### 71. Auto Parts
- Energy Management
- Waste Management
- Product Safety
- Design for Fuel Efficiency : Automobile manufacturers increasingly are demanding motor parts and components that reduce vehicle fuel consumption.
- Materials Sourcing
- Materials Efficiency
- Competitive Behaviour

### 72. Automobiles
- Product Safety
- Labour Practices
- Fuel Economy & Use-phase Emissions : Motor vehicle fossil fuel combustion accounts for a significant share of the greenhouse gas (GHG) emissions contributing to global climate change.
- Materials Sourcing
- Materials Efficiency & Recycling

### 73. Car Rental & Leasing
- Customer Safety
- Fleet Fuel Economy & Utilisation : By providing fuel-efficient and alternative fuel vehicles, car rental and leasing entities may improve the environmental sustainability of their operations while also achieving financial benefits.

### 74. Cruise Lines
- Greenhouse Gas Emissions
- Air Quality
- Discharge Management & Ecological Impacts
- Customer Health & Safety
- Labour Practices
- Workforce Health & Safety
- Accident Management : Although cruise ships are one of the safest forms of travel for holidays, the industry competes on customer experience and satisfaction, making safety management a top priority.

### 75. Marine Transportation
- Greenhouse Gas Emissions
- Air Quality
- Ecological Impacts
- Workforce Health & Safety
- Business Ethics
- Accident & Safety Management : Accidents or leaks involving large vessels can have significant impacts on life, property and the environment.

### 76. Rail Transportation
- Greenhouse Gas Emissions
- Air Quality
- Workforce Health & Safety
- Competitive Behaviour
- Accident & Safety Management : Rail accidents and unintended releases of hazardous materials have negative repercussions for the environment and communities along railroad tracks, as well as financial effects on entities themselves.

### 77. Road Transportation
- Greenhouse Gas Emissions
- Air Quality
- Workforce Conditions, Health & Safety
- Accident & Safety Management : Road transportation involves inherent dangers, including accidents resulting from mechanical failure or human error.
