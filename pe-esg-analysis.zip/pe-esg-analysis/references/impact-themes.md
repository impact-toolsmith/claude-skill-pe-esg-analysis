# Product and service impact themes (theme selection list)

When the products or services have a positive impact, name the theme(s) from this list, using ONLY the theme names in the analysis. The examples in brackets are there solely to guide theme selection and must never be reproduced in the output.

- Low-carbon energy (examples, for guidance only: solar, wind, hydro, biomass, geothermal, smart grids)
- Low-carbon mobility (examples, for guidance only: electric / hydrogen vehicles, public transportation, cycles, route optimization)
- Green buildings (examples, for guidance only: insulation, low-carbon heating and air conditioning, intelligent consumption management, green building materials)
- Green industry (examples, for guidance only: energy efficiency of industrial processes, green chemistry, circularity)
- Sustainable food (examples, for guidance only: certified agriculture (organic, fair trade), precision agriculture, plant-based food)
- Nature-based solutions (examples, for guidance only: reforestation, forest protection, vegetation)
- Sustainable waste & water management (examples, for guidance only: waste sorting & recycling, leak reduction, smart irrigation, access to clean water, sanitation and waste management)
- Sustainable consumption (examples, for guidance only: certified products, eco-design, circular economy, packaging reduction, alternatives to plastic, sustainable raw materials / ingredients, eco-tourism)
- Better health for all (examples, for guidance only: diagnostics, treatments, prevention, care, medical equipment, access to health)
- Education & knowledge (examples, for guidance only: education, lifelong learning, knowledge bases, access to education & information, courses on sustainability)
- Social housing (examples, for guidance only: development, maintenance & dedicated services)
- Safety (examples, for guidance only: dedicated safety equipment, testing, cyber security)
- Tackling inequalities (examples, for guidance only: gender diversity, people with disabilities, access to quality employment, access to essential services)
- Sustainable ICT (examples, for guidance only: energy-efficient hardware, energy-efficient data centres, ESG software, dematerialisation, new technologies fostering sustainability)
- Sustainable finance (examples, for guidance only: micro-credit, sustainable finance, access to financial services)
