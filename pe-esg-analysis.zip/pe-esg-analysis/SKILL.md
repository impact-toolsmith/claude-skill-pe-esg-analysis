---
name: pe-esg-analysis
description: Produces an ESG analysis of a private equity target company in one of three formats (ultra-short verdict, short one-pager, or long structured report). On launch it asks which format is wanted, unless a format was already imposed by a shortcut skill (pe-esg-analysis-ultra-short / -short / -long). Use whenever the user asks for an ESG (or CSR/RSE) analysis, an ESG screening, an ESG one-pager, an ESG report, or an ESG opinion for an investment committee, or provides a company name (and possibly a website, a memo, or a document-store link) expecting an ESG opinion, even without using the word ESG.
---

# PE ESG Analysis (ultra-short, short one-pager, or long report)

This skill produces an ESG analysis of a private equity target company, for investment committees and deal memos. It exists in three formats that share the same source collection and method but differ in output length:
- Ultra-short: a one or two sentence verdict.
- Short: a one-pager (three dense paragraphs, under 2000 characters) plus a complementary synthesis.
- Long: a full structured report (three sections with subsections and financial impacts) plus a complementary synthesis.

## Installation configuration
Set at install time; leave the defaults if unsure. These settings are baked into this file when the skill is installed.
- Analysis mode: full            (choose "light" or "full"; light = token-optimised, recommended for free or small plans)
- Default analysis language: match source documents            (or a specific language)
- Optional modules (long format only): none            (any of: competitor-benchmark, exclusion-screening, double-materiality)
- Exclusion list: references/exclusion-list.md            (optional; used if exclusion-screening is enabled and this file exists; otherwise a standard PE exclusion set is applied)

Installer note: to keep this file lean, you may delete the analysis-mode branch you did not choose and the optional-module descriptions you did not enable.

## Step 0: determine the format
- If a format was already imposed by the call (e.g. invoked from pe-esg-analysis-ultra-short / -short / -long, or the user already said "ultra-short"/"verdict", "short"/"one-pager", or "long"/"full report"), do not ask: keep that format and go straight to source collection.
- Otherwise, ask the user a single short multiple-choice question for the format. Use the same interaction to confirm, if needed, the company name and the source(s) to use.

## Inputs and source collection
The only indispensable input is the target company name. Everything else is supplied by the user and/or actively gathered by Claude from the sources the user provides. Accept any combination of:
- a document-store link (SharePoint, Google Drive, Box, a data room, etc.),
- an information memorandum (IM) / confidential information memorandum (CIM) / "info memo" (the same document),
- an internal investment note or memo,
- a company name,
- a website URL.

Before launching, briefly confirm with the user (ideally in the same interaction as the format choice): the target company name, and which source(s) to use (a link, an uploaded document, or a search by company name). Do not re-ask for information that is accessible in the sources provided.

Then actively gather the sources. Distinguish two families:
1. External deal documentation (from the sell-side / M&A advisor). The IM/CIM is central: it is the factual reference on the company (activity, product mix, clients, geography, headcount, executives, ownership). Read it in full, even if large (by chunks or via a dedicated sub-agent). If text extraction fails or is partial (flattened graphical PDF, truncated export), do not assume it has been read: check coverage and complete missing sections via a page-by-page visual read in a sub-agent; if still impossible, ask the user to provide the IM rather than silently proceeding, and flag the gap in Sources. Also look for the teaser, vendor due diligence (financial / strategic / ESG), management presentation, Q&A and due-diligence reports.
2. Internal investment documents. These are the source of the internal reading (thesis, view on management quality and governance, watch points) and of the tone, language and committee stage. Look for the internal opportunity sheet / one-pager and the investment committee notes.

Read both families. Never conclude on the business from internal documents alone, nor on governance and management quality from the IM alone.

Identify the company website from the IM or internal note; failing that, via web search. Complete with the public research described in the method below.

## Mandatory user check-ins
Two situations require asking the user before continuing (one short question each):
1. Ambiguous company name or website. If the company name is common, maps to several legal entities, or it is unclear which website/entity is the target, ask the user to confirm the exact name and website before proceeding. Never analyse the wrong entity.
2. No information memorandum. If no IM was provided, or it cannot be found in the document store the user supplied, explicitly ask the user to confirm that no IM exists (or to provide it) before continuing. Do not silently proceed as if the IM were simply absent: its absence materially changes the analysis and must be acknowledged and recorded in Sources.

## Documentary prerequisites
Before producing the analysis, check that the indispensable documents are present. If one is missing, do not launch: warn the user in one or two sentences (stating which document is missing and where it was searched) and ask whether to continue anyway or provide it.
- IM (all formats): indispensable in all cases. If unavailable and the user cannot provide it, do not launch without the user's explicit agreement to proceed anyway.
- Short format: the internal one-pager (if the user's process produces one) is recommended.
- Long format: the internal one-pager and the first investment committee note are recommended.
- Ultra-short format: only the IM is indispensable; internal notes are useful but not blocking (this format is meant for rapid screening).
If the user agrees to proceed despite a missing document, do so and flag the gap explicitly in the Sources section.

## Output language
If a default analysis language was configured at installation, write the analysis in that language. Otherwise, write in the same language as the internal investment documents if any; failing that, the language of the IM; failing that, English.

## Method (common to all formats)
1. Retrieve and read the provided sources: external deal documentation (IM first) for the factual base, and internal investment documents for the thesis, governance and management quality.
2. Systematically explore the company website for ESG content. Do not rely on the home page or a generic search. Fetch the typical pages: About / Company; Sustainability / CSR / Commitments / Impact; Quality / Certifications / QHSE; Careers; Legal information (footer often lists certification logos); Timeline / Key dates; flagship product pages (sometimes quantified impact data); Press / News. This exploration is mandatory before concluding that ESG content, a formalised CSR policy, or certifications are absent.
3. Search for controversies via web search on two axes: the company and its sector; and the named executives identified in the IM or internal notes (at minimum founder(s), CEO / Chair, main operating shareholders).
4. Systematically check employee reviews (Glassdoor, Indeed, etc.) and client reviews (Trustpilot, Google Reviews, sector forums). Mandatory even if nothing notable comes out. When the clientele is exclusively institutional / B2B / B2G, note that consumer review platforms are not relevant and read satisfaction from other signals (tender win rate, framework agreements, renewals). Browser fallback: many review platforms block direct fetching (anti-scraping); when a fetch returns empty while search shows reviews exist, switch to a rendered-browser read; if access remains impossible, say so rather than pretending to rely on a source you could not read.
5. If the sector is known for recurring controversies, run dedicated research on documented sector incidents (dates, places, magnitudes, operator involved, fines).
6. Load the SASB sector checklist: read the bundled file references/sasb-disclosure-topics.md, locate the target's sector (search by industry name) and read only that block. SASB is the best available exercise for identifying sector issues: use it to verify that no material issue has been forgotten, and reuse an issue's wording as-is when relevant. This is not mandatory: some SASB issues are very relevant to the target, others less so; adapt, merge or drop case by case. Keep your own report structure and format.
7. Identify the investment committee stage (early screening vs commitment) and calibrate the recommendation accordingly.
8. Write the analysis strictly in the format chosen at Step 0.

## Analysis mode (light vs full)
Apply the mode set in the installation configuration.
- Full mode: run the method above exactly as described (thorough). This is more token-intensive.
- Light mode (token-optimised, for free or small plans): reduce consumption as follows, accepting less depth, while keeping the same output structure:
  - IM: read it via a dedicated sub-agent that returns only a tight ESG extract (activity, product/revenue mix, clients, geography, headcount, executives, ownership, and any ESG / HSE / governance mentions); prefer text extraction; use page-by-page image reads only for the few sections where text extraction fails. Do not load the full IM into the main context.
  - SASB: extract only the target's sector block from references/sasb-disclosure-topics.md with a targeted search (grep), never read the whole file into context.
  - Web research: limit controversy searches to the one or two key executives; fetch only the core website pages (About, Sustainability, Quality); prefer search snippets over full-page fetches; use a rendered browser only when a direct fetch fails; skip the dedicated sector-incident deep dive.

## Committee-stage calibration
- Early screening committee: do not lay out ESG improvement roadmaps or value-creation levers. Flag gaps factually ("not communicated at this stage").
- Later / commitment committee: improvement areas, action plans and value-creation levers become relevant.

## Output formats
Apply only the format chosen at Step 0.
- Ultra-short: deliver the verdict (one or two sentences) in the conversation; no file.
- Short: deliver the one-pager text in the conversation; no file unless explicitly asked.
- Long: generate a Word report with the bundled script scripts/render_esg_long.py (self-contained: it builds the .docx from scratch, no external template and no logo), then present the .docx. See "Long-format Word output" below for the Markdown contract and the command.

---

## > ULTRA-SHORT FORMAT (one or two sentence ESG verdict)
Produces a very tight ESG verdict: one or two sentences, keeping only the potentially problematic points (exposure to an excluded activity, a poorly managed material environmental or social risk, a confirmed controversy on the company or an executive, concerning governance). This is a rapid screening format.

Run the full method anyway (sources, website, controversies on company and executives, employee and client reviews, SASB checklist): the output is short, but the verdict must rest on the same analytical depth as the other formats. Do not cut corners on research because the output is brief.

Rules:
- One or two sentences maximum, no title, no bullets, no table.
- Mention only what is potentially problematic. If there is little to flag, say so simply, e.g.: "Limited ESG issues: B2B services activity with no particular material exposure, no controversy identified on the company or its executives."
- When there are watch points, state them directly and factually, from most to least material, without listing mitigations or improvement areas. If a point rests on a controversy, give its nature (and date) in a few words.
- Stay factual and calibrated to the committee stage.

The complementary synthesis, the Sources section, the governance-quality rating and any report file do not apply to the ultra-short format.

---

## > SHORT FORMAT (one-pager, under 2000 characters)
Three dense paragraphs, no titles, in this order:

Paragraph 1, Products and services (title the angle "products", "services" or "products and services" depending on what the company mainly sells). How the products / services address environmental or social issues, or conversely raise problems; quantify the share of revenue exposed when available. Enter directly through the ESG angle without re-describing the activity. When the activity has a positive impact, name the relevant impact theme(s) from the Impact themes list (Appendix A), using only the theme names, not the sub-theme examples. If impacts are limited, say so in one sentence and move on; do not look for indirect angles that read as filler.

Paragraph 2, ESG risks. Main environmental and social risks given the sector and model, and how the company responds (certifications, formalised policies, dedicated team, published indicators). Aim for at least three risks for an industrial or exposed company, numbered (i), (ii), (iii). Do not confuse sustainability risks with the business model's financial risks. For each risk, state explicitly whether online research surfaced a controversy.

Paragraph 3, Governance. Ownership, management stability, upcoming changes, specific risks. Prefer people-centred elements over structures. Reuse any internal material on management quality. Close with the governance quality rating: "Governance quality: <level>" (scale below); this line is outside the 2000-character count.

Total body under 2000 characters (excluding sources and complementary synthesis). No titles or subtitles in the body.

---

## > LONG FORMAT (full ESG report)
Opens with a synthesis, then three main sections with Markdown titles, each with subsections.

# Synthesis: up to three paragraphs giving an overall ESG reading, readable on its own; do not re-describe the activity; do not open with a global ESG grade; qualify issue by issue; one sentence on governance; one sentence on the controversy review result. The synthesis table is generated automatically; its products/services row shows the section name followed by the main impact theme, e.g. "Impacts of services: Education & knowledge".

# Impacts of products and services: name this section "Impacts of products" if the company mainly sells products, "Impacts of services" if it mainly sells services, or "Impacts of products and services" if both. How products / services address or harm environmental and social issues; quantify exposed revenue and a sourced order of magnitude of impact when relevant. Pick the relevant impact theme(s) from the Impact themes list (references/impact-themes.md, Appendix A), using only the theme names; never reproduce the sub-theme examples, which are there only to guide your selection. Mandatory subsection ## Potential financial impacts, followed by its level (Strong / Medium / Weak) and a sign (+ / = / -) when Strong or Medium.

# Main environmental and social risks: at most five subsections, one per main risk, each titled ## with (Exposure: Strong / Medium / Weak | Maturity: Very advanced / Advanced / Medium / Limited / Poor practices / ?). For each risk: a first paragraph on why it is a risk for this specific company; one or more paragraphs on what the company does about it; mandatory subsection ### Potential financial impacts (level plus sign). Exposure to exclusion policies is never a risk in this section.

# Governance (Governance quality: <level>): ## Economic governance (with ### Potential financial impacts), ## CSR governance (no financial-impact subsection), and ## Business ethics if a Medium or Strong ethics/compliance issue exists (with ### Potential financial impacts). Business ethics, when included, is titled exactly "Business ethics" and carries both Exposure and Maturity in its title bar (like a risk), not Maturity alone.

Notations: each risk carries (Exposure | Maturity); each financial-impact subsection carries its level (and + / = / - if Strong or Medium); the governance section title carries the governance quality rating.

### Long-format Word output (self-contained script)
Deliver the long report as a Word file produced by scripts/render_esg_long.py. The script is self-contained: it builds the .docx from scratch (synthesis table, coloured title blocks, pillar pastilles), with no external template and no logo. Do not hand-craft the Word or write XML: write the analysis to a Markdown file following the contract below, then run the script.

Markdown contract:

TITLE: <Company name>
SUBTITLE: Full ESG report  |  <committee stage>  |  <month year>

# Synthesis
<synthesis paragraphs>      (the synthesis table is inserted AUTOMATICALLY; do not write it)

# Impacts of products and services      (rename to "Impacts of products" or "Impacts of services" per scope)
[HEADER] scope=<products|services|both> | note=<Strong|Medium|Weak> | pillar=<E|S|E/S> | exposure=<Direct|Indirect> | themes=<main theme first, names from the Impact themes list>
<paragraphs>
### Potential financial impacts (Medium, +)
<paragraphs>

# Main environmental and social risks
## [S] <Risk title> (Exposure: Strong | Maturity: Advanced)
<paragraphs>
### Potential financial impacts (Medium, -)
<paragraphs>
## [E] <Risk title> (Exposure: Medium | Maturity: Limited)
... (up to 5 risks; each title prefixed with the pillar [E], [S] or [E/S])

# Governance
## [G] Economic governance (Maturity: Medium)
<paragraphs>
### Potential financial impacts (Medium, +)
<paragraphs>
## [G] CSR governance (Maturity: Limited)
<paragraphs>
## [G] Business ethics (Exposure: Medium | Maturity: Medium)   (include only if a Medium/Strong ethics or compliance issue exists)
<paragraphs>
### Potential financial impacts (Medium, =)
<paragraphs>

# Complementary synthesis
## Employee reviews
## Client reviews
## Online controversy review
## Controversy review on executives

# Sources
<paragraphs>

(If optional modules are enabled, add their appendix sections here, after Sources, each as a "# Appendix - ..." heading followed by a Markdown table; see "Optional modules".)

Contract rules:
- The tags [E] / [S] / [E/S] / [G], the [HEADER] line and the (Maturity: ...) / (Exposure: ... | Maturity: ...) notations are consumed by the script and do not appear as such in the Word: they drive the pastilles, the colours and the synthesis table.
- Governance: in the Word, the governance rating is not global in the # Governance title; each subsection carries it via ## [G] ... (Maturity: <level>).
- Business ethics: include this [G] subsection only when a Medium or Strong ethics/compliance issue exists; title it exactly "Business ethics" and give it both Exposure and Maturity, e.g. ## [G] Business ethics (Exposure: Medium | Maturity: Medium), so its title bar shows exposure like a risk.
- Synthesis table: generated automatically from the pillars, ratings and "Potential financial impacts" of each block. The overall arrow ++ / + / = / - / -- combines Exposure and Maturity (default matrix); the $ marker follows the financial-impact sign (green if +, orange if -). Override the matrix when needed with a "| Synthesis: <arrow>" token, e.g. (Exposure: Strong | Maturity: Medium | Synthesis: -).
- scope drives the section label in the synthesis table; the synthesis row shows that label followed by ": " and the main impact theme (the first theme listed in themes). Use theme names from the Impact themes list only; never the sub-theme examples.
- Plain paragraphs stay plain text.

Command:
python3 scripts/render_esg_long.py --content analysis.md --out "ESG Analysis - CompanyName.docx"

Then present the produced .docx.

---

## Optional modules (long format only)
Produce a module only if it is listed in the installation configuration, and only in the long format (never in ultra-short or short). Each module is an appendix at the end of the report, after Sources, rendered as a table using the Markdown-table syntax below (the Word script turns it into a bordered table). Keep modules factual; never fabricate ratings or facts.
- competitor-benchmark -> "# Appendix - Competitor ESG benchmark". Identify the target's main competitors automatically (from the IM and the sector), unless the user specifies particular competitors. Table columns: Company | Certifications / ratings | ESG commitments | Controversies. Put the target on the first data row, then the competitors.
- exclusion-screening -> "# Appendix - Exclusion screening". Screen the target against every criterion in references/exclusion-list.md if that file is present. If it is absent (the user did not provide a list), screen instead against the standard exclusions commonly used by private-equity investors: controversial or prohibited weapons, tobacco production, thermal coal and coal-fired power generation, oil and gas extraction, gambling, adult entertainment, predatory lending, and activities in breach of the UN Global Compact principles. Table columns: Exclusion criterion | Status | Note, where Status is Compliant, Exposed, or To verify.
- double-materiality -> "# Appendix - Double materiality (SASB)". Over the target's SASB sector topics, assess two axes. Table columns: SASB topic | Impact materiality | Financial materiality | Comment, where each materiality is High, Medium or Low (impact = the company's effect on the environment and society; financial = the effect of the issue on the company).

Markdown-table syntax (header row, separator row, then data rows):
| Column A | Column B | Column C |
| --- | --- | --- |
| value | value | value |

## Section naming and impact themes (common)
Name the products/services impacts section, and its row in the synthesis table, "Impacts of products" if the company mainly sells products, "Impacts of services" if it mainly sells services, or "Impacts of products and services" if both. Choose the impact theme(s) from the Impact themes list (references/impact-themes.md, Appendix A of the installation guide). Use only the theme names in the analysis; the sub-theme examples in that list are there solely to guide your theme selection and must never appear in the output. In the synthesis table, the products/services row is followed by the main impact theme, e.g. "Impacts of services: Education & knowledge".

## Taking a position on financial impacts (common)
In each "potential financial impacts" subsection, take a position: cite positives and negatives but conclude one way or the other, or state explicitly that they balance out. Avoid the "Positively... Negatively..." structure. The level and sign must be consistent with the position taken.

## Governance quality rating (common, not for ultra-short)
Always provide an overall governance-quality rating on the scale below (use ? rather than inventing a rating):
- Very advanced: exemplary, formalised governance (structured and active bodies, strong alignment of executives, prepared succession, robust compliance and internal control, no blind spots).
- Advanced: solid governance, aligned and experienced executives, bodies in place, minor and controlled watch points.
- Medium: functional but improvable (key-person dependence, succession not yet prepared, partial formalisation, some related parties to frame).
- Limited: loosely structured governance, significant dependencies or blind spots, low formalisation, missing information.
- Poor practices: confirmed negative signals (unaddressed conflicts of interest, opacity, executives' judicial or disciplinary records, governance litigation).
- ?: insufficient information to rate (flag the missing elements).

## Certifications glossary (common)
Always state what each cited certification is for and attach it to the pillar it actually addresses, e.g. ISO 9001 (quality), ISO 14001 (environment), ISO 45001 (occupational health and safety), ISO 50001 (energy management), ISO 27001 (information security), EcoVadis (supplier CSR rating, Bronze / Silver / Gold / Platinum), B Corp (certified mission-driven company). Distinguish certifications from certifying bodies (e.g. Bureau Veritas, SGS, TUV, Apave, Dekra certify; they are not certifications). Explain every sector acronym and in-house product or tool name at first use.

## Complementary synthesis (short and long formats only)
After the main body, produce four short, distinct syntheses with dedicated titles, mandatory even when research found nothing notable (not for ultra-short): 1. Employee reviews; 2. Client reviews; 3. Online controversy review (company); 4. Controversy review on executives (named). Keep each short. For each review block, report the overall rating and review volume, recurring themes, and any alert signals; do not detail sub-category scores.

## Sources (short and long formats only)
List the sources consulted in two categories: information provided by the company in the process (state the nature of the information, without naming each internal document individually; if the document store could not be located or used, say so); and external sources, named (website with the specific pages visited, company registries, press, court decisions, web searches with main keywords).

## Writing constraints and pitfalls
- Deliver per format (ultra-short / short: text in the conversation; long: written report).
- Factual, measured, analytical tone; no activist jargon or greenwashing. Never invent figures (headcount, revenue, % of revenue on a theme, emissions, online ratings).
- Do not name internal documents in the body; present facts directly; for missing information write "not communicated to us at this stage".
- Do not make exposure to exclusion policies a risk in the "Main environmental and social risks" section; treat it, only if material, under the products/services impacts section.
- Do not confuse sustainability risks with the business model's financial risks.
- Do not confuse indirect sector exposure with direct impact; characterise the real degree of operational involvement (platform / network / franchise / intermediation models).
- Never claim "no ISO certification" / "no formalised CSR policy" / "no carbon footprint" without first fetching the site's About / Company / Sustainability / Quality / Certifications / Legal information / Timeline pages.
- Do not list acronyms (certifications or sector terms) without a short gloss at first use.
- Do not omit the complementary synthesis (short and long), even when all research is inconclusive.
